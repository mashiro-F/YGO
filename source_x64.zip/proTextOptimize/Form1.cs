﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SQLite;
using System.Net;
using System.IO;
using System.Text;
using System.Diagnostics;
using Microsoft.VisualBasic.Devices;

namespace proTextOptimize
{
	public partial class TestForm : Form
    {
		const string dbName = "isomer.db";

		const string dbNameNew = "isomerNew.db";

		private static readonly string path = Environment.CurrentDirectory;

		private static readonly string url = "https://raw.githubusercontent.com/mashiro-F/YGO/master/version.txt";

		private static readonly string urldb = "https://gitee.com/mashirof/YGO/raw/master/isomer.db";

		public TestForm()
        {
			VersionCheck(url, path + "\\" + dbName);
            InitializeComponent();
        }

		private void button1_Click(object sender, EventArgs e)
		{
			int num = this.DBStateCheck(TestForm.path);
			this.CopyNewText(TestForm.path, num);
			bool flag = num == 0;
			if (flag)
			{
				this.Backups(TestForm.path);
				this.OptimizeTexts(TestForm.path);
			}
			else
			{
				this.OptimizeTexts(TestForm.path);
			}
			MessageBox.Show("效果文本替换成功");
		}

		private void button2_Click(object sender, EventArgs e)
		{
			int num = this.TableStateCheck(TestForm.path);
			bool flag = num == 1;
			if (flag)
			{
				this.RollBackTexts(TestForm.path);
			}
			MessageBox.Show("效果文本还原成功");
		}

		public void Backups(string path) //保存原文本
		{
			SQLiteConnection sqliteConnection = new SQLiteConnection("data source=" + path + "\\cards.cdb");
			sqliteConnection.Open();
			new SQLiteCommand
			{
				Connection = sqliteConnection,
				CommandText = "Alter TABLE texts ADD COLUMN desc_2 text;update texts set desc_2=desc;"
			}.ExecuteNonQuery();
			sqliteConnection.Close();
		}

		public void CopyNewText(string path, int state) //插入新文本
		{
			SQLiteConnection sqliteConnection = new SQLiteConnection("data source=" + path + "\\cards.cdb");
			sqliteConnection.Open();
			SQLiteCommand sqliteCommand = new SQLiteCommand();
			sqliteCommand.Connection = sqliteConnection;
			bool flag = state == 0;
			if (flag)
			{
				sqliteCommand.CommandText = "ATTACH '" + path + "\\isomer.db' as test;CREATE TABLE IF NOT EXISTS newText as select * from test.newText;";
			}
			else
			{
				sqliteCommand.CommandText = "ATTACH '" + path + "\\isomer.db' as test;DELETE FROM newText;Insert into newText select * from test.newText;";
			}
			sqliteCommand.ExecuteNonQuery();
			sqliteConnection.Close();
		}

		public void OptimizeTexts(string path) //替换文本
		{
			SQLiteConnection sqliteConnection = new SQLiteConnection("data source=" + path + "\\cards.cdb");
			sqliteConnection.Open();
			new SQLiteCommand
			{
				Connection = sqliteConnection,
				CommandText = "update texts set desc=(select desc_1 from newText where texts.id=newText.Id) where exists(select* from newText where newText.Id= texts.id)"
			}.ExecuteNonQuery();
			sqliteConnection.Close();
		}

		public void RollBackTexts(string path) //还原文本
		{
			SQLiteConnection sqliteConnection = new SQLiteConnection("data source=" + path + "\\cards.cdb");
			sqliteConnection.Open();
			new SQLiteCommand
			{
				Connection = sqliteConnection,
				CommandText = "update texts set desc=desc_2"
			}.ExecuteNonQuery();
			sqliteConnection.Close();
		}

		public int DBStateCheck(string path)
		{
			int result = 0;
			SQLiteConnection sqliteConnection = new SQLiteConnection("data source=" + path + "\\cards.cdb");
			sqliteConnection.Open();
			SQLiteCommand sqliteCommand = sqliteConnection.CreateCommand();
			sqliteCommand.CommandText = "select name from sqlite_master where type='table'";
			SQLiteDataReader sqliteDataReader = sqliteCommand.ExecuteReader(CommandBehavior.CloseConnection);
			while (sqliteDataReader.Read())
			{
				bool flag = sqliteDataReader.GetString(0) == "newText";
				if (flag)
				{
					result = 1;
				}
			}
			sqliteDataReader.Close();
			return result;
		}

		public int TableStateCheck(string path)
		{
			int result = 0;
			SQLiteConnection sqliteConnection = new SQLiteConnection("data source=" + path + "\\cards.cdb");
			sqliteConnection.Open();
			SQLiteCommand sqliteCommand = sqliteConnection.CreateCommand();
			sqliteCommand.CommandText = "PRAGMA table_info('texts')";
			SQLiteDataReader sqliteDataReader = sqliteCommand.ExecuteReader(CommandBehavior.CloseConnection);
			while (sqliteDataReader.Read())
			{
				for (int i = 0; i < sqliteDataReader.FieldCount; i++)
				{
					bool flag = sqliteDataReader[i].ToString() == "desc_2";
					if (flag)
					{
						result = 1;
					}
				}
			}
			sqliteDataReader.Close();
			return result;
		}

		private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			System.Diagnostics.Process.Start("http://tieba.baidu.com/home/main?un=%E7%9C%9F%E7%BA%A2%E7%9C%BC%E7%9A%84%E9%92%A2%E7%82%8E%E7%AB%9C&fr=ibaidu&ie=utf-8");
		}

		public string GetMD5HashFromHttp(string url)
		{
			try
			{
				HttpWebRequest myRequest = (HttpWebRequest)HttpWebRequest.Create(url);

				Stream readStream = myRequest.GetResponse().GetResponseStream();

				StreamReader reader = new StreamReader(readStream);

				string version = reader.ReadToEnd();

				return version;
			}
			catch (Exception)
			{
				return "wrong";
			}
		}

		public string GetMD5HashFromFile(string filename)
		{
			try
			{
				FileStream file = new FileStream(filename, FileMode.Open);
				System.Security.Cryptography.MD5 md5 = new System.Security.Cryptography.MD5CryptoServiceProvider();
				byte[] retVal = md5.ComputeHash(file);
				file.Close();

				StringBuilder sb = new StringBuilder();
				for (int i = 0; i < retVal.Length; i++)
				{
					sb.Append(retVal[i].ToString("x2"));
				}
				return sb.ToString();
			}
			catch (System.Exception ex)
			{
				Debug.Assert(false, "错误信息：" + ex);
				return null;
			}

		}

		public bool Download(string url, string localfile)
		{
			bool flag = false;
			long startPosition = 0; // 上次下载的文件起始位置
			FileStream writeStream; // 写入本地文件流对象

			long remoteFileLength = GetHttpLength(url);// 取得远程文件长度
			System.Console.WriteLine("remoteFileLength=" + remoteFileLength);
			if (remoteFileLength == 745)
			{
				System.Console.WriteLine("远程文件不存在.");
				return false;
			}

			// 判断要下载的文件夹是否存在
			if (File.Exists(localfile))
			{

				writeStream = File.OpenWrite(localfile);             // 存在则打开要下载的文件
				startPosition = writeStream.Length;                  // 获取已经下载的长度

				if (startPosition >= remoteFileLength)
				{
					System.Console.WriteLine("本地文件长度" + startPosition + "已经大于等于远程文件长度" + remoteFileLength);
					writeStream.Close();

					return false;
				}
				else
				{
					writeStream.Seek(startPosition, SeekOrigin.Current); // 本地文件写入位置定位
				}
			}
			else
			{
				writeStream = new FileStream(localfile, FileMode.Create);// 文件不保存创建一个文件
				startPosition = 0;
			}


			try
			{
				HttpWebRequest myRequest = (HttpWebRequest)HttpWebRequest.Create(url);// 打开网络连接

				if (startPosition > 0)
				{
					myRequest.AddRange((int)startPosition);// 设置Range值,与上面的writeStream.Seek用意相同,是为了定义远程文件读取位置
				}


				Stream readStream = myRequest.GetResponse().GetResponseStream();// 向服务器请求,获得服务器的回应数据流


				byte[] btArray = new byte[512];// 定义一个字节数据,用来向readStream读取内容和向writeStream写入内容
				int contentSize = readStream.Read(btArray, 0, btArray.Length);// 向远程文件读第一次

				long currPostion = startPosition;

				while (contentSize > 0)// 如果读取长度大于零则继续读
				{
					currPostion += contentSize;
					int percent = (int)(currPostion * 100 / remoteFileLength);
					System.Console.WriteLine("percent=" + percent + "%");

					writeStream.Write(btArray, 0, contentSize);// 写入本地文件
					contentSize = readStream.Read(btArray, 0, btArray.Length);// 继续向远程文件读取
				}

				//关闭流
				writeStream.Close();
				readStream.Close();

				flag = true;        //返回true下载成功
			}
			catch (Exception)
			{
				writeStream.Close();
				flag = false;       //返回false下载失败
			}

			return flag;
		}

		// 从文件头得到远程文件的长度
		private long GetHttpLength(string url)
		{
			long length = 0;

			try
			{
				HttpWebRequest req = (HttpWebRequest)HttpWebRequest.Create(url);// 打开网络连接
				HttpWebResponse rsp = (HttpWebResponse)req.GetResponse();

				if (rsp.StatusCode == HttpStatusCode.OK)
				{
					length = rsp.ContentLength;// 从文件头得到远程文件的长度
				}

				rsp.Close();
				return length;
			}
			catch (Exception)
			{
				return length;
			}

		}

		public void VersionCheck(string url,string filename)
		{
			string MD5Web = GetMD5HashFromHttp(url);

			string MD5 = GetMD5HashFromFile(filename);

			if (!Equals(MD5Web, "wrong"))
			{
				if (!Equals(MD5Web, MD5))
				{
					DialogResult dr = MessageBox.Show("检测到有新版本文本，是否要更新", "更新文本", MessageBoxButtons.OKCancel);
					if (dr == DialogResult.OK)
					{
						if (Download(urldb, path + "\\" + dbNameNew))
						{
							DeleteDirectory(path + "\\" + dbName);
							RenameDirectory(path + "\\" + dbNameNew);
							MessageBox.Show("更新成功");
						}
						else
						{
							MessageBox.Show("更新失败，请检查网络");
						}
					}
				}
			}
		}

		public void DeleteDirectory(string directoryPath)
		{
			if (File.Exists(directoryPath))
			{
				File.Delete(directoryPath);
			}
		}

		public void RenameDirectory(string directoryPath)
		{
			if (File.Exists(directoryPath))
			{
				Computer MyComputer = new Computer();
				MyComputer.FileSystem.RenameFile(directoryPath, "isomer.db");
			}
		}
	}
}
